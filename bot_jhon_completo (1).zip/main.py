
import discord
import random
import asyncio
import os

intents = discord.Intents.default()
intents.messages = True
client = discord.Client(intents=intents)

with open("falas_jhon_10000.txt", "r", encoding="utf-8") as f:
    falas = f.readlines()

commands = {
    "!beijo": "https://media.giphy.com/media/KH1CTZtw1iP3W/giphy.gif",
    "!carinho": "https://media.giphy.com/media/l0HlNQ03J5JxX6lva/giphy.gif",
    "!abraço": "https://media.giphy.com/media/143v0Z4767T15e/giphy.gif",
    "!elogio": "https://media.giphy.com/media/l0ExncehJzexFpRHq/giphy.gif",
    "!provoca": "https://media.giphy.com/media/3oKIPwoeGErMmaI43C/giphy.gif",
    "!dengo": "https://media.giphy.com/media/XreQmk7ETCak0/giphy.gif",
    "!chama": "https://media.giphy.com/media/3o6Zt481isNVuQI1l6/giphy.gif",
    "!manda": "https://media.giphy.com/media/xT5LMHxhOfscxPfIfm/giphy.gif",
    "!saudade": "https://media.giphy.com/media/l3V0lsGtTMSB5YNgc/giphy.gif",
    "!mimo": "https://media.giphy.com/media/l0MYB8Ory7Hqefo9a/giphy.gif"
}

@client.event
async def on_ready():
    print(f"Bot conectado como {client.user}")
    while True:
        await asyncio.sleep(14400)  # 4 horas
        canal = discord.utils.get(client.get_all_channels(), name="geral")
        if canal:
            await canal.send(random.choice(falas))

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content in commands:
        gif = commands[message.content]
        frase = random.choice(falas)
        await message.channel.send(frase)
        await message.channel.send(gif)

    elif any(word in message.content.lower() for word in ["amor", "saudade", "fofo", "lindo", "beijo", "quero"]):
        await message.channel.send(random.choice(falas))

token = os.getenv("DISCORD_TOKEN")
client.run(token)
